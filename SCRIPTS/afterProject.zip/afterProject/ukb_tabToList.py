#!/hpc/local/CentOS7/dhl_ec/software/python37/bin/python3 

"""
Python script that creates a sample list from a tab file, created by ukb_extract_phenos.sh
This is use case specific, the columns are hard coded !!!!
Written by Moezammin Baksi
"""

import os
import numpy as np
import sys


# Function to check for stroke
def gotStroke(icd10headers, line):
    for col in icd10headers:
        if 'I639' in line[col]:
            return True
    return False


# Function to parse the headers of the ICD10
def parseHeaders(line):
    headers = []
    strokeheaders = []
    for index, name in enumerate(line.split()):
        if name.split('.')[1].startswith('eid'):
            headers.append('ID')
        elif name.split('.')[1].startswith('31'):
            headers.append('Sex')
        elif name.split('.')[1].startswith('21003'):
            headers.append('Age')
        elif name.split('.')[1].startswith('21000'):
            headers.append('Etnic')
        elif name.split('.')[1].startswith('41202'):
            headers.append('ICD10')
            strokeheaders.append(index)
        elif name.split('.')[1].startswith('22000'):
            headers.append('GenotypeBatch')
        elif name.split('.')[1].startswith('22009'):
            component = name.split('.')[-1]
            headers.append('PC' + component)
    return headers, strokeheaders


# Function to check whether a sample withdrew consent
def withdrawnConsent(line, withdrawnConsentList):
    return line[0] in withdrawnConsentList


# Function to delete existing files and write cases/controls
def writeOutput(outList, outFile, ids=False):
    if os.path.exists(outFile):
        os.remove(outFile)
    with open(outFile, "a") as myfile:
        for sample in outList:
            if ids:
                myfile.write(sample[0] + "\n")
            else:
                for word in sample:
                    myfile.write(word + "\t")
                myfile.write("\n")
    

# Open files
tabFile = sys.argv[1]
consentFile = sys.argv[2]
casesOut = sys.argv[3]
controlsOut = sys.argv[4]

# Parse the consent list
withdrawnConsentList = []
f = open(consentFile)
for line in f:
    withdrawnConsentList.append(line.split()[0])
f.close()

# Variables to store the patients
cases = []
controls = []

# Perform reading
f = open(tabFile)
icd10headers = []
orgHeaders = []
count = 0
for line in f:
    if len(icd10headers) < 1:
        headers, icd10headers = parseHeaders(line)
        # orgHeaders = line.split()
        headers.append("IS")
        # orgHeaders.append("IS")
    else:
        # Check for withdrawn consent, if so append to either cases or controls
        if not withdrawnConsent(line.split(), withdrawnConsentList):
            if gotStroke(icd10headers, line.split()):
                toAdd = []
                for i in range(len(line.split())):
                    if i not in icd10headers:
                        toAdd.append(line.split()[i])
                toAdd.append("1") # Add IS
                cases.append(toAdd)
            else:
                toAdd = []
                for i in range(len(line.split())):
                    if i not in icd10headers:
                        toAdd.append(line.split()[i])
                toAdd.append("0") # Add IS
                controls.append(toAdd)
f.close()

# Choose the controls for this project
np.random.seed(1022021) # Start date of internship :)
randomControlsIndex = np.random.choice(range(len(controls)), size=len(cases), replace=False)
randomControls = [controls[x] for x in randomControlsIndex]

# Write the samples them to text files
writeOutput(cases, casesOut + "_idList.txt", ids=True)
writeOutput(randomControls, controlsOut + "_idList.txt", ids=True)

# Remove icd10 headers and write to data
fixedHeaders = []
for x in headers:
    if not x.startswith('ICD10'):
        fixedHeaders.append(x)
writeOutput([fixedHeaders] + cases, casesOut + "_data.txt")
writeOutput([fixedHeaders] + randomControls, controlsOut + "_data.txt")

