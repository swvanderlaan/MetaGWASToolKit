#!/bin/bash
#SBATCH --time=48:00:00
#SBATCH --mem=128G

plink=/hpc/local/CentOS7/dhl_ec/software/plink-2dev_20210525/plink2


$plink \
    --bgen /hpc/ukbiobank/genetic_v3/ukb_imp_chr${1}_v3.bgen 'ref-first' \
    --sample /hpc/dhl_ec/data/ukbiobank/genetic_v3/ukb24711_imp_chr${1}_v3_s487371.sample \
    --keep $2 \
    --make-bed \
    --out /hpc/dhl_ec/mbaksi/ukbb/abdul/data/ukbb_chr${1}_
