#!/bin/bash
#SBATCH --cpus-per-task=8
#SBATCH --time=72:00:00
#SBATCH --mem=256G
#SBATCH -o /hpc/dhl_ec/mbaksi/ukbb/abdul/data/log/regenie.log   
#SBATCH -e /hpc/dhl_ec/mbaksi/ukbb/abdul/data/log/regenie.errors 

# Vars
plink2=/hpc/local/CentOS7/dhl_ec/software/plink-2dev_20210525/plink2
plink=/hpc/local/CentOS7/dhl_ec/software/plink_v1.9
DATADIR=/hpc/dhl_ec/mbaksi/ukbb/abdul/data/
bcftools=/hpc/local/CentOS7/dhl_ec/software/bcftools/bcftools
vcftools=/hpc/local/CentOS7/dhl_ec/software/vcftools_v0.1.14
regenie=/hpc/dhl_ec/mbaksi/ukbb/abdul/scripts/regenie_v2.0.2.gz_x86_64_Centos7_mkl
OUTDIR=/hpc/dhl_ec/mbaksi/ukbb/abdul/out/


# Filter multiallelic using bcftools, need to convert to vcf first
# This steps takes in a lot of temp space, you might not want to do this in paralel if you are low on disk space.
for i in {1..23..1}
    do 
        sbatch --wait --job-name=bcf_${i} --error=/hpc/dhl_ec/mbaksi/ukbb/abdul/data/log/bcf${i}.errors --output=/hpc/dhl_ec/mbaksi/ukbb/abdul/data/log/bcf${i}.log --mem=128GB --time=15:00:00 --cpus-per-task=64 ukb_bcffilter.sh $plink $DATADIR ${i} $bcftools
    done

# Create bed file, used in merging
rm -f ${OUTDIR}list_beds.txt
for chr in {1..22}; do echo "${DATADIR}ukbb_fil_chr${chr}_.bed ${DATADIR}ukbb_fil_chr${chr}_.bim ${DATADIR}ukbb_fil_chr20_.fam" >> ${OUTDIR}list_beds.txt; done


# PROBLEM!
# Even after filtering for only biallelic variants, I still get this error message:
# * If you believe this is due to strand inconsistency, try --flip with
#   Myfile_Chr1-merge.missnp.
#   (Warning: if this seems to work, strand errors involving SNPs with A/T or C/G
#   alleles probably remain in your data.  If LD between nearby SNPs is high,
#   --flip-scan should detect them.)
# * If you are dealing with genuine multiallelic variants, we recommend exporting
#   that subset of the data to VCF (via e.g. '--recode vcf'), merging with
#   another tool/script, and then importing the result; PLINK is not yet suited
#   to handling them.

# Merge files
$plink \
  --bed ${DATADIR}ukbb_fil_chr1_.bed \
  --bim ${DATADIR}ukbb_fil_chr1_.bim \
  --fam ${DATADIR}ukbb_fil_chr1_.fam \
  --merge-list ${OUTDIR}list_beds.txt \
  --exclude ${DATADIR}ukbb_allChrs-merge.missnp \
  --make-bed --out ${DATADIR}ukbb_allChrs



# # QC
# $plink2 \
#   --bfile ${DATADIR}ukbb_fil_allChrs \
#   --maf 0.01 --mac 100 --geno 0.1 --hwe 1e-15 \
#   --mind 0.1 \
#   --write-snplist --write-samples --no-id-header \
#   --out ${OUTDIR}regenie_qc_pass


# # Use regenie
# $regenie \
#   --step 1 \
#   --bed ${DATADIR}ukbb_fil_allChrs \
#   --extract ${OUTDIR}regenie_qc_pass.snplist \
#   --keep ${OUTDIR}regenie_qc_pass.id \
#   --phenoFile ukb_phenotypes_BT.txt \
#   --covarFile ukb_covariates.txt \
#   --bt \
#   --bsize 1000 \
#   --lowmem \
#   --lowmem-prefix /hpc/dhl_ec/mbaksi/ukbb/abdul/out/temp/regenie_tmp_preds \
#   --out ${OUTDIR}ukb_step1_BT