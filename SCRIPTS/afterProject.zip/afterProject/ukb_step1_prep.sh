#!/bin/bash
#SBATCH --time=24:00:00   
#SBATCH --mem=256G
#SBATCH -o /hpc/dhl_ec/mbaksi/ukbb/abdul/data/log/ukb_main.log   
#SBATCH -e /hpc/dhl_ec/mbaksi/ukbb/abdul/data/log/ukb_main.errors  

# This script extracts phontypes, contact Abdul/Moezammin for information
# Called scripts are form Abdul Alasiri (phd candidate)

################################################### VARS ###################################################
# Some variables
# TAB delimited file with all the data, make sure to select the right version
PHENOFILE=/hpc/dhl_ec/data/ukbiobank/phenotypic/ukb44641.tab 

# File to be created with the fields of choice
IDFILE=/hpc/dhl_ec/mbaksi/ukbb/abdul/field.txt

# Output dir and name of project, will eventually create files like out/sexIS_ukb_phenotypes.info  out/sexIS_ukb_phenotypes.tab
OUTDIR=/hpc/dhl_ec/mbaksi/ukbb/abdul/out/
PROJECTNAME=sexIS

# Consent file for patients to remove
# Copied from: File for withdrawn consent: /hpc/dhl_ec/aalasiri/ARVC_GWAS/QC_LV/participants_withdraw_fromUKB_Feb2021.txt
CONSENT=/hpc/dhl_ec/mbaksi/ukbb/abdul/withdrawnconsent.txt

# Outfiles for cases/controls, NO FILE EXTENSION
CASESOUT=/hpc/dhl_ec/mbaksi/ukbb/abdul/out/casesPy
CONTROLSOUT=/hpc/dhl_ec/mbaksi/ukbb/abdul/out/controlsPy

# Genomic samples, gotten by awking a column from the sample file
# cat /hpc/dhl_ec/data/ukbiobank/genetic_v3/ukb24711_imp_chr1_v3_s487371.sample | awk '{print $1}' > genomicSamples.txt
GENOMIC=/hpc/dhl_ec/mbaksi/ukbb/abdul/genomicSamples.txt

# Overlap script (pl)
OVERLAPSCRIPT=/hpc/local/CentOS7/dhl_ec/software/overlap.pl

# Sample file (one random)
EXAMPLESAMPLE=/hpc/dhl_ec/data/ukbiobank/genetic_v3/ukb24711_imp_chr1_v3_s487371.sample 

# DATA dir, so where the genomic data (.bed .bim .fam) is stored
DATADIR=/hpc/dhl_ec/mbaksi/ukbb/abdul/data/

# Plink 
plink=/hpc/local/CentOS7/dhl_ec/software/plink-2dev_20210525/plink2

# Bcftools
bcftools=/hpc/local/CentOS7/dhl_ec/software/bcftools/bcftools

# Regenie
regenie=/hpc/dhl_ec/mbaksi/ukbb/abdul/scripts/regenie_v2.0.2.gz_x86_64_Centos7_mkl
############################################### END VARS ###################################################


# Step 0: Start the script
dt=$(date '+%d/%m/%Y %H:%M:%S');
echo "Starting ..."
echo "$dt"


# Step 1: Create a field.txt with the required fields for your analysis
rm -fv $IDFILE
touch $IDFILE
echo -e 'FieldID'"\t"'Field' >> $IDFILE
echo -e '31'"\t"'Sex' >> $IDFILE
echo -e '21003'"\t"'Age when attended assessment centre' >> $IDFILE
echo -e '21000'"\t"'Ethnic background' >> $IDFILE
echo -e '41202'"\t"'Diagnoses - main ICD10' >> $IDFILE
echo -e '22000'"\t"'Genotype measurement batch' >> $IDFILE
echo -e '22009'"\t"'Genetic principal components' >> $IDFILE
# Dummy line, in case the script requires empty line at the end of the script
echo -e ' ' >> $IDFILE  


# Step 2: Call script to excecute the phenotype extraction based on the field.txt you just created
./ukb_pheno_v1.sh $PHENOFILE $IDFILE $OUTDIR $PROJECTNAME


# Step 3: Call python script to create the sample list files and the case/control files
OUTTAB=$OUTDIR$PROJECTNAME"_ukb_phenotypes.tab"
python3 ukb_tabToList.py $OUTTAB $CONSENT $CASESOUT $CONTROLSOUT


# Step 4: Count the overlap between genomic data and the created samples/controls
# Zhou, W. et al. Efficiently controlling for case-control imbalance and sample relatedness in large-scale genetic association studies. Nature Genetics 50, 1335–1341 (2018).
echo "Counting cases ..."
$OVERLAPSCRIPT $EXAMPLESAMPLE 1 ${CASESOUT}_idList.txt 1 | wc -l
echo "Counting Controls ..."
$OVERLAPSCRIPT $EXAMPLESAMPLE 1 ${CONTROLSOUT}_idList.txt 1 | wc -l


# Step 5: Prepare data for BOLT-LMM
# Create ID file, which contains all ids to extract from the genomic data
rm -fv ${OUTDIR}idforplink.txt
cat ${CONTROLSOUT}_idList.txt | awk '{print $1,$1}' >> ${OUTDIR}idforplink.txt
cat ${CASESOUT}_idList.txt | awk '{print $1,$1}' >> ${OUTDIR}idforplink.txt

# Then extract these samples for every chromosome
# This steps takes in a lot of temp space, you might not want to do this in paralel if you are low on disk space. 
for i in {1..23..1}
    do 
        sbatch --job-name=cv_${i} --error /hpc/dhl_ec/mbaksi/ukbb/abdul/data/log/chr${i}.errors --output /hpc/dhl_ec/mbaksi/ukbb/abdul/data/log/chr${i}.log ukb_bgen2bed.sh ${i} ${OUTDIR}idforplink.txt
    done


# Ending
dt=$(date '+%d/%m/%Y %H:%M:%S');
echo "Finishing ..."
echo "$dt"


# FieldID Field
# 31      Sex
# 21003   Age when attended assessment centre
# 21000   Ethnic background
# 41202   Diagnoses - main ICD10
# 22000   Genotype measurement batch
# 22009   Genetic principal components
