#!/bin/bash

plink=$1
DATADIR=$2
i=$3
bcftools=$4

$plink --bfile ${DATADIR}ukbb_chr${i}_ --recode vcf --out ${DATADIR}ukbb_vcf_chr${i}_ --threads 64
gzip ${DATADIR}ukbb_vcf_chr${i}_.vcf
$bcftools view -m2 -M2 -v snps ${DATADIR}ukbb_vcf_chr${i}_.vcf.gz --output-type v -o ${DATADIR}ukbb_vcf_fil_chr${i}_.vcf --threads 64 
$plink --vcf ${DATADIR}ukbb_vcf_fil_chr${i}_.vcf --make-bed --out ${DATADIR}ukbb_fil_chr${i}_ --threads 64
gzip ${DATADIR}ukbb_vcf_fil_chr${i}_.vcf
