# Welcome
This markdown file describes the project folder, to make it less hard to understand the structure and files.

Written by Moezammin Baksi BSc

moez-baksi@hotmail.com

February 2021 - June 2021

## The MetaGWASToolKit
GitHub: https://github.com/swvanderlaan/MetaGWASToolKit

### Results of meta-analysis, stratified by sex:
Output directories can be found under:
```bash
realpath /hpc/dhl_ec/mbaksi/MetaGWASToolKit/sexstratification_*
```

### Fixing headers using `/hpc/dhl_ec/mbaksi/scripts/fixheaders.py`:
```bash
# B is the basename of the RAW cohort file
# F is the realpath to the RAW cohort file
# D is the directory to store the output
sbatch --job-name=fix.${B} --time 01:00:00 -o example.${B}.log -e example.${B}.errors fixheaders.py --file ${F} --outdir ${D}

# The 'fixed' headers files can be found here:
ls /hpc/dhl_ec/mbaksi/MetaGWASToolKit/RAWDATA/*_cols_edit.gz
```

### Intended usage of the toolkit:
```bash
# Create a folder for the separate phenotype / ancestry
# Within this folder: copy the files from git: metagwastoolkit.qsub.sh, metagwastoolkit.conf, metagwastoolkit.files.list, metagwastoolkit.params
# Adjust the lists and paramaters as you like in config file and files list
# Uncomment the two first steps from the qsub file (leave the rest commented)

# Excecute these steps:
# A is the ancestry
# P is the phenotype
cd /hpc/dhl_ec/mbaksi/MetaGWASToolKit/sexstratification_${A}_${P}/
sbatch metagwastoolkit.qsub.sh

# Manually inspect the plots
# Use the paramsfile script to semi-automatically create the parameters file
```
``` Python
# NOTE: You have to manually remove the cohorts with a lambda < 1! This is not a bug but a feature!
# NOTE: This script is writting in Python3, with their way to calculate the lambda:
z = scipy.stats.norm.ppf(df['P']/2) # Where df['P'] are the P-values
lamb = round(statistics.median(z*z)/scipy.stats.chi2.ppf(0.5, 1),3)) 
# In all my cases it was the same when calculated using the existing funtions in R (qqplotter.R), you might want to double check!
```
```bash
# This will create a params.txt in the specified folder, which can be copy pasted in the metagwastoolkit.params 
# B is the basename of the EDITED (fixed headers) cohort file
# P is the realpath to the project folders, e.g. /hpc/dhl_ec/mbaksi/MetaGWASToolKit/sexstratification_Alpha_Female
sbatch --job-name=${B}.params --time 01:00:00 -o example.${B}.log -e example.${B}.errors Paramfile.py --path ${P}


# Now you can comment the first two steps, and uncomment the rest of the steps and excecute it! 
cd /hpc/dhl_ec/mbaksi/MetaGWASToolKit/sexstratification_${A}_${P}/
sbatch metagwastoolkit.qsub.sh
```

## Creating Powerpoint
During this project, I generated a powerpoint using `/hpc/dhl_ec/mbaksi/scripts/Generateppt.py`

Because this script is very speciffic for every use case, it contains some hardcoding

However, I do think most of the code is readable and reusable, just look out for paths, filenames, etc. 
```Bash
sbatch --wrap "python3 Generateppt.py"
```

## Mr-mega
### flipped data
I manually edited some european files to match 1000G using `/hpc/dhl_ec/mbaksi/scripts/AFrefplot.py` and `/hpc/dhl_ec/mbaksi/scripts/checkAlleleorder.py`

To replicate this:
```Bash
# FIRST create ref:
zcat /hpc/dhl_ec/data/references/1000G/Phase1/VCF_format/ALL.wgs.integrated_phase1_v3.20101123.snps.sites.vcf.gz | grep -v "##" | awk '{ print $1, $2, $3, $4, $5, $6, $7, $8, $9}' > /hpc/dhl_ec/mbaksi/output/1000G/referenceFull.txt

# Check for flipping
# P is one of the files you want to check for flipping, example: /hpc/dhl_ec/mbaksi/MetaGWASToolKit/sexstratification_Gamma_Male/METAGWAS/Gamma_Male/RAW/WTCCC2_UK_MEN_20100717_csv/WTCCC2_UK_MEN_20100717_csv.cdat.gz
# B is the basename of these files
# EUR is the ancestry, I only did this for european cohorts
sbatch --job-name=${B}.or  -o example.${B}.log -e example.${B}.errors checkAlleleorder.py ${P} EUR


# This will check if the reverse of a variant fits better according to 1000G, and switch if so.
# The resulting file is located in /hpc/dhl_ec/mbaksi/output/flippedData/
# You should gzip this file
cd /hpc/dhl_ec/mbaksi/output/flippedData/
ls /hpc/dhl_ec/mbaksi/output/flippedData/*txt > temp.txt

while IFS="" read -r p || [ -n "$p" ]
do
  sbatch --job-name=zip.${p}  --wrap="gzip ${p}"
done < "temp.txt"
rm temp.txt

# This result file is then used in the plot script:
# P2 is the resulting file, for example /hpc/dhl_ec/mbaksi/output/flippedData/WTCCC2_UK_WOMEN_20100717_csv.cdat.txt.gz
# EUR is the ancestry, I only did this for european cohorts
sbatch --job-name=${p2}.AF  -o example.log -e example.errors AFrefplot.py ${p2} EUR
```
The flipped data files should be used as input the MR-MEGA

### MR-MEGA usage
To get the code from source: `wget http://www.geenivaramu.ee/tools/MR-MEGA_v0.2.zip`

You have to specify the files you want to include in (for each phenotype):
```Bash
ls /hpc/dhl_ec/mbaksi/MR-MEGA_data/MR-MEGA_F.in
ls /hpc/dhl_ec/mbaksi/MR-MEGA_data/MR-MEGA_M.in
# And these files contain the path to the cdat files created in the first two steps of the MetaGWASToolKit:
# Example entry:
/hpc/dhl_ec/mbaksi/MetaGWASToolKit/sexstratification_Beta_Female/METAGWAS/Beta_Female/RAW/BBJ_7_female_20160413/BBJ_7_female_20160413.cdat.gz
# And then execute  by putting this code in a .sh script and excecuting with sbatch (64gb RAM, three hours):
echo 'FEMALE'
/hpc/dhl_ec/mbaksi/MR-MEGA/MR-MEGA \
--qt \
--filelist /hpc/dhl_ec/mbaksi/MR-MEGA_data/MR-MEGA_F.in \
--out /hpc/dhl_ec/mbaksi/MR-MEGA_data/FEMALE \
--name_marker VARIANTID \
--name_ea EffectAllele \
--name_nea OtherAllele \
--name_eaf EAF \
--name_beta Beta \
--name_se SE \
--name_n N \
--name_chr CHR \
--name_pos BP \
--pc 5
```

The principal components can be extracted from the .log files and plotted. 

The .result file is the output of this tool. 

Note that this file is pretty big (Too big for FUMA), so you might want to gzip and/or extract only necessary columns.

```Bash
# NOTE: The specific awk columns depends on which PC's you want to use!
cat MALE.result | awk '{if ($10!="NA") print $1,$2,$3,$4,$5,$6,$7,$10,$11,$24}' > choose_a_cool_filename.txt
gzip choose_a_cool_filename.txt
```

## UK-Biobank
Sample files chr2, but others are availble: `/hpc/dhl_ec/data/ukbiobank/genetic_v3/ukb24711_imp_chr2_v3_s487371.sample`
Uk biobank data: `/hpc/dhl_ec/data/ukbiobank/phenotypic/ukb44641.tab`
Used the ukb_step1_prep.sh script to do everything related to ukbiobank.
And any other step2 script thereafter.
Overall bolt works, but regenie needs some fixing
```

## Other scripts
THe other scripts were merely created to quickly fix or investigate something or were too specific for this project to be reused (such as SEN.py), which I do not think is neccesary to fully understand, but you can always contact me!