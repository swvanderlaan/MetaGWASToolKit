#!/bin/bash
#SBATCH --cpus-per-task 8
#SBATCH --time=15:00:00
#SBATCH --mem=256G
#SBATCH -o /hpc/dhl_ec/mbaksi/ukbb/abdul/data/log/bolt.log   
#SBATCH -e /hpc/dhl_ec/mbaksi/ukbb/abdul/data/log/bolt.errors 

bolt_dir=/hpc/dhl_ec/mbaksi/ukbb/abdul/scripts/BOLT-LMM_v2.3.4
plink=/hpc/local/CentOS7/dhl_ec/software/plink-2dev_20210525/plink2

# A minimal BOLT-LMM invocation looks like:
# ./bolt --bfile=geno --phenoFile=pheno.txt --phenoCol=phenoName
#      --lmm --LDscoresFile=tables/LDSCORE.1000G_EUR.tab.gz
#      --statsFile=stats.tab

$bolt_dir/bolt \
    --bed=/hpc/dhl_ec/mbaksi/ukbb/abdul/data/ukbb_chr{1:22}_.bed \
    --bim=/hpc/dhl_ec/mbaksi/ukbb/abdul/data/ukbb_chr{1:22}_.bim \
    --fam=/hpc/dhl_ec/mbaksi/ukbb/abdul/data/ukbb_chr1_.fam \
    --phenoFile=/hpc/dhl_ec/mbaksi/ukbb/abdul/out/phenoForBolt.txt \
    --phenoCol=IS \
    --LDscoresFile=$bolt_dir/tables/LDSCORE.1000G_EUR.tab.gz \
    --lmm \
    --maxModelSnps=150000000 \
    --statsFile=/hpc/dhl_ec/mbaksi/ukbb/abdul/out/bolt.stats_v2.gz \
    --numThreads=64




# To create phenofile
# head -1 casesPy_data.txt | awk 'BEGIN { OFS = "\t" } {print $1,$0}' > phenoForBolt.txt
# Manually edit first two cols to FID IID
# (base) [mbaksi@hpcs03 out]$ tail -n +2 casesPy_data.txt | awk 'BEGIN { OFS = "\t" } {print $1,$0}' >> phenoForBolt.txt
# (base) [mbaksi@hpcs03 out]$ tail -n +2 controlsPy_data.txt | awk 'BEGIN { OFS = "\t" } {print $1,$0}' >> phenoForBolt.txt
